﻿namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tigerPlayedCard = new System.Windows.Forms.PictureBox();
            this.hawkPlayedCard = new System.Windows.Forms.PictureBox();
            this.sharkPlayedCard = new System.Windows.Forms.PictureBox();
            this.playerPlayedCard = new System.Windows.Forms.PictureBox();
            this.playersHand = new System.Windows.Forms.GroupBox();
            this.playerCard12 = new System.Windows.Forms.PictureBox();
            this.playerCard11 = new System.Windows.Forms.PictureBox();
            this.playerCard10 = new System.Windows.Forms.PictureBox();
            this.playerCard9 = new System.Windows.Forms.PictureBox();
            this.playerCard8 = new System.Windows.Forms.PictureBox();
            this.playerCard7 = new System.Windows.Forms.PictureBox();
            this.playerCard6 = new System.Windows.Forms.PictureBox();
            this.playerCard5 = new System.Windows.Forms.PictureBox();
            this.playerCard4 = new System.Windows.Forms.PictureBox();
            this.playerCard3 = new System.Windows.Forms.PictureBox();
            this.playerCard2 = new System.Windows.Forms.PictureBox();
            this.playerCard1 = new System.Windows.Forms.PictureBox();
            this.playerCard0 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sharkCard13 = new System.Windows.Forms.PictureBox();
            this.sharkCard12 = new System.Windows.Forms.PictureBox();
            this.sharkCard11 = new System.Windows.Forms.PictureBox();
            this.sharkCard10 = new System.Windows.Forms.PictureBox();
            this.sharkCard9 = new System.Windows.Forms.PictureBox();
            this.sharkCard8 = new System.Windows.Forms.PictureBox();
            this.sharkCard7 = new System.Windows.Forms.PictureBox();
            this.sharkCard6 = new System.Windows.Forms.PictureBox();
            this.sharkCard5 = new System.Windows.Forms.PictureBox();
            this.sharkCard4 = new System.Windows.Forms.PictureBox();
            this.sharkCard3 = new System.Windows.Forms.PictureBox();
            this.sharkCard2 = new System.Windows.Forms.PictureBox();
            this.sharkCard1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hawkCard1 = new System.Windows.Forms.PictureBox();
            this.hawkCard2 = new System.Windows.Forms.PictureBox();
            this.hawkCard3 = new System.Windows.Forms.PictureBox();
            this.hawkCard4 = new System.Windows.Forms.PictureBox();
            this.hawkCard5 = new System.Windows.Forms.PictureBox();
            this.hawkCard6 = new System.Windows.Forms.PictureBox();
            this.hawkCard7 = new System.Windows.Forms.PictureBox();
            this.hawkCard8 = new System.Windows.Forms.PictureBox();
            this.hawkCard9 = new System.Windows.Forms.PictureBox();
            this.hawkCard10 = new System.Windows.Forms.PictureBox();
            this.hawkCard11 = new System.Windows.Forms.PictureBox();
            this.hawkCard12 = new System.Windows.Forms.PictureBox();
            this.hawkCard13 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tigerCard13 = new System.Windows.Forms.PictureBox();
            this.tigerCard12 = new System.Windows.Forms.PictureBox();
            this.tigerCard11 = new System.Windows.Forms.PictureBox();
            this.tigerCard10 = new System.Windows.Forms.PictureBox();
            this.tigerCard9 = new System.Windows.Forms.PictureBox();
            this.tigerCard8 = new System.Windows.Forms.PictureBox();
            this.tigerCard7 = new System.Windows.Forms.PictureBox();
            this.tigerCard6 = new System.Windows.Forms.PictureBox();
            this.tigerCard5 = new System.Windows.Forms.PictureBox();
            this.tigerCard4 = new System.Windows.Forms.PictureBox();
            this.tigerCard3 = new System.Windows.Forms.PictureBox();
            this.tigerCard2 = new System.Windows.Forms.PictureBox();
            this.tigerCard1 = new System.Windows.Forms.PictureBox();
            this.rulesButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.showScoreButton = new System.Windows.Forms.Button();
            this.dealButton = new System.Windows.Forms.Button();
            this.continueButton = new System.Windows.Forms.Button();
            this.leadingSuitTextBox = new System.Windows.Forms.TextBox();
            this.newGameButton = new System.Windows.Forms.Button();
            this.cheatButton = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tigerPlayedCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkPlayedCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkPlayedCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPlayedCard)).BeginInit();
            this.playersHand.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard0)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard13)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tigerPlayedCard);
            this.groupBox3.Controls.Add(this.hawkPlayedCard);
            this.groupBox3.Controls.Add(this.sharkPlayedCard);
            this.groupBox3.Controls.Add(this.playerPlayedCard);
            this.groupBox3.Location = new System.Drawing.Point(425, 190);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(519, 358);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Trick";
            // 
            // tigerPlayedCard
            // 
            this.tigerPlayedCard.Location = new System.Drawing.Point(215, 19);
            this.tigerPlayedCard.Name = "tigerPlayedCard";
            this.tigerPlayedCard.Size = new System.Drawing.Size(75, 100);
            this.tigerPlayedCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerPlayedCard.TabIndex = 1;
            this.tigerPlayedCard.TabStop = false;
            // 
            // hawkPlayedCard
            // 
            this.hawkPlayedCard.Location = new System.Drawing.Point(377, 127);
            this.hawkPlayedCard.Name = "hawkPlayedCard";
            this.hawkPlayedCard.Size = new System.Drawing.Size(75, 100);
            this.hawkPlayedCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkPlayedCard.TabIndex = 1;
            this.hawkPlayedCard.TabStop = false;
            // 
            // sharkPlayedCard
            // 
            this.sharkPlayedCard.Location = new System.Drawing.Point(53, 127);
            this.sharkPlayedCard.Name = "sharkPlayedCard";
            this.sharkPlayedCard.Size = new System.Drawing.Size(75, 100);
            this.sharkPlayedCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkPlayedCard.TabIndex = 1;
            this.sharkPlayedCard.TabStop = false;
            // 
            // playerPlayedCard
            // 
            this.playerPlayedCard.Location = new System.Drawing.Point(215, 252);
            this.playerPlayedCard.Name = "playerPlayedCard";
            this.playerPlayedCard.Size = new System.Drawing.Size(75, 100);
            this.playerPlayedCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerPlayedCard.TabIndex = 1;
            this.playerPlayedCard.TabStop = false;
            // 
            // playersHand
            // 
            this.playersHand.Controls.Add(this.playerCard12);
            this.playersHand.Controls.Add(this.playerCard11);
            this.playersHand.Controls.Add(this.playerCard10);
            this.playersHand.Controls.Add(this.playerCard9);
            this.playersHand.Controls.Add(this.playerCard8);
            this.playersHand.Controls.Add(this.playerCard7);
            this.playersHand.Controls.Add(this.playerCard6);
            this.playersHand.Controls.Add(this.playerCard5);
            this.playersHand.Controls.Add(this.playerCard4);
            this.playersHand.Controls.Add(this.playerCard3);
            this.playersHand.Controls.Add(this.playerCard2);
            this.playersHand.Controls.Add(this.playerCard1);
            this.playersHand.Controls.Add(this.playerCard0);
            this.playersHand.Location = new System.Drawing.Point(176, 658);
            this.playersHand.Name = "playersHand";
            this.playersHand.Size = new System.Drawing.Size(1081, 131);
            this.playersHand.TabIndex = 0;
            this.playersHand.TabStop = false;
            this.playersHand.Text = "Your Hand";
            // 
            // playerCard12
            // 
            this.playerCard12.Enabled = false;
            this.playerCard12.Location = new System.Drawing.Point(978, 19);
            this.playerCard12.Name = "playerCard12";
            this.playerCard12.Size = new System.Drawing.Size(75, 100);
            this.playerCard12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard12.TabIndex = 1;
            this.playerCard12.TabStop = false;
            this.playerCard12.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard11
            // 
            this.playerCard11.Enabled = false;
            this.playerCard11.Location = new System.Drawing.Point(897, 19);
            this.playerCard11.Name = "playerCard11";
            this.playerCard11.Size = new System.Drawing.Size(75, 100);
            this.playerCard11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard11.TabIndex = 1;
            this.playerCard11.TabStop = false;
            this.playerCard11.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard10
            // 
            this.playerCard10.Enabled = false;
            this.playerCard10.Location = new System.Drawing.Point(816, 19);
            this.playerCard10.Name = "playerCard10";
            this.playerCard10.Size = new System.Drawing.Size(75, 100);
            this.playerCard10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard10.TabIndex = 1;
            this.playerCard10.TabStop = false;
            this.playerCard10.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard9
            // 
            this.playerCard9.Enabled = false;
            this.playerCard9.Location = new System.Drawing.Point(735, 19);
            this.playerCard9.Name = "playerCard9";
            this.playerCard9.Size = new System.Drawing.Size(75, 100);
            this.playerCard9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard9.TabIndex = 1;
            this.playerCard9.TabStop = false;
            this.playerCard9.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard8
            // 
            this.playerCard8.Enabled = false;
            this.playerCard8.Location = new System.Drawing.Point(654, 19);
            this.playerCard8.Name = "playerCard8";
            this.playerCard8.Size = new System.Drawing.Size(75, 100);
            this.playerCard8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard8.TabIndex = 1;
            this.playerCard8.TabStop = false;
            this.playerCard8.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard7
            // 
            this.playerCard7.Enabled = false;
            this.playerCard7.Location = new System.Drawing.Point(573, 19);
            this.playerCard7.Name = "playerCard7";
            this.playerCard7.Size = new System.Drawing.Size(75, 100);
            this.playerCard7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard7.TabIndex = 1;
            this.playerCard7.TabStop = false;
            this.playerCard7.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard6
            // 
            this.playerCard6.Enabled = false;
            this.playerCard6.Location = new System.Drawing.Point(492, 19);
            this.playerCard6.Name = "playerCard6";
            this.playerCard6.Size = new System.Drawing.Size(75, 100);
            this.playerCard6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard6.TabIndex = 1;
            this.playerCard6.TabStop = false;
            this.playerCard6.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard5
            // 
            this.playerCard5.Enabled = false;
            this.playerCard5.Location = new System.Drawing.Point(411, 19);
            this.playerCard5.Name = "playerCard5";
            this.playerCard5.Size = new System.Drawing.Size(75, 100);
            this.playerCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard5.TabIndex = 1;
            this.playerCard5.TabStop = false;
            this.playerCard5.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard4
            // 
            this.playerCard4.Enabled = false;
            this.playerCard4.Location = new System.Drawing.Point(330, 19);
            this.playerCard4.Name = "playerCard4";
            this.playerCard4.Size = new System.Drawing.Size(75, 100);
            this.playerCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard4.TabIndex = 1;
            this.playerCard4.TabStop = false;
            this.playerCard4.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard3
            // 
            this.playerCard3.Enabled = false;
            this.playerCard3.Location = new System.Drawing.Point(249, 19);
            this.playerCard3.Name = "playerCard3";
            this.playerCard3.Size = new System.Drawing.Size(75, 100);
            this.playerCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard3.TabIndex = 1;
            this.playerCard3.TabStop = false;
            this.playerCard3.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard2
            // 
            this.playerCard2.Enabled = false;
            this.playerCard2.Location = new System.Drawing.Point(168, 19);
            this.playerCard2.Name = "playerCard2";
            this.playerCard2.Size = new System.Drawing.Size(75, 100);
            this.playerCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard2.TabIndex = 1;
            this.playerCard2.TabStop = false;
            this.playerCard2.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard1
            // 
            this.playerCard1.Enabled = false;
            this.playerCard1.Location = new System.Drawing.Point(87, 19);
            this.playerCard1.Name = "playerCard1";
            this.playerCard1.Size = new System.Drawing.Size(75, 100);
            this.playerCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard1.TabIndex = 1;
            this.playerCard1.TabStop = false;
            this.playerCard1.Click += new System.EventHandler(this.playerClick);
            // 
            // playerCard0
            // 
            this.playerCard0.BackColor = System.Drawing.SystemColors.Control;
            this.playerCard0.Enabled = false;
            this.playerCard0.Location = new System.Drawing.Point(6, 19);
            this.playerCard0.Name = "playerCard0";
            this.playerCard0.Size = new System.Drawing.Size(75, 100);
            this.playerCard0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playerCard0.TabIndex = 1;
            this.playerCard0.TabStop = false;
            this.playerCard0.Click += new System.EventHandler(this.playerClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.sharkCard13);
            this.groupBox1.Controls.Add(this.sharkCard12);
            this.groupBox1.Controls.Add(this.sharkCard11);
            this.groupBox1.Controls.Add(this.sharkCard10);
            this.groupBox1.Controls.Add(this.sharkCard9);
            this.groupBox1.Controls.Add(this.sharkCard8);
            this.groupBox1.Controls.Add(this.sharkCard7);
            this.groupBox1.Controls.Add(this.sharkCard6);
            this.groupBox1.Controls.Add(this.sharkCard5);
            this.groupBox1.Controls.Add(this.sharkCard4);
            this.groupBox1.Controls.Add(this.sharkCard3);
            this.groupBox1.Controls.Add(this.sharkCard2);
            this.groupBox1.Controls.Add(this.sharkCard1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 774);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shark\'s Hand";
            // 
            // sharkCard13
            // 
            this.sharkCard13.Image = global::FinalProject.Properties.Resources.Backface_Red2;
            this.sharkCard13.Location = new System.Drawing.Point(26, 691);
            this.sharkCard13.Name = "sharkCard13";
            this.sharkCard13.Size = new System.Drawing.Size(100, 50);
            this.sharkCard13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard13.TabIndex = 1;
            this.sharkCard13.TabStop = false;
            // 
            // sharkCard12
            // 
            this.sharkCard12.Image = global::FinalProject.Properties.Resources.Backface_Red2;
            this.sharkCard12.Location = new System.Drawing.Point(26, 635);
            this.sharkCard12.Name = "sharkCard12";
            this.sharkCard12.Size = new System.Drawing.Size(100, 50);
            this.sharkCard12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard12.TabIndex = 1;
            this.sharkCard12.TabStop = false;
            // 
            // sharkCard11
            // 
            this.sharkCard11.Image = global::FinalProject.Properties.Resources.Backface_Red2;
            this.sharkCard11.Location = new System.Drawing.Point(26, 579);
            this.sharkCard11.Name = "sharkCard11";
            this.sharkCard11.Size = new System.Drawing.Size(100, 50);
            this.sharkCard11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard11.TabIndex = 1;
            this.sharkCard11.TabStop = false;
            // 
            // sharkCard10
            // 
            this.sharkCard10.Image = global::FinalProject.Properties.Resources.Backface_Red2;
            this.sharkCard10.Location = new System.Drawing.Point(26, 523);
            this.sharkCard10.Name = "sharkCard10";
            this.sharkCard10.Size = new System.Drawing.Size(100, 50);
            this.sharkCard10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard10.TabIndex = 1;
            this.sharkCard10.TabStop = false;
            // 
            // sharkCard9
            // 
            this.sharkCard9.Image = global::FinalProject.Properties.Resources.Backface_Red2;
            this.sharkCard9.Location = new System.Drawing.Point(26, 467);
            this.sharkCard9.Name = "sharkCard9";
            this.sharkCard9.Size = new System.Drawing.Size(100, 50);
            this.sharkCard9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard9.TabIndex = 1;
            this.sharkCard9.TabStop = false;
            // 
            // sharkCard8
            // 
            this.sharkCard8.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard8.Image")));
            this.sharkCard8.Location = new System.Drawing.Point(26, 411);
            this.sharkCard8.Name = "sharkCard8";
            this.sharkCard8.Size = new System.Drawing.Size(100, 50);
            this.sharkCard8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard8.TabIndex = 1;
            this.sharkCard8.TabStop = false;
            // 
            // sharkCard7
            // 
            this.sharkCard7.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard7.Image")));
            this.sharkCard7.Location = new System.Drawing.Point(26, 355);
            this.sharkCard7.Name = "sharkCard7";
            this.sharkCard7.Size = new System.Drawing.Size(100, 50);
            this.sharkCard7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard7.TabIndex = 1;
            this.sharkCard7.TabStop = false;
            // 
            // sharkCard6
            // 
            this.sharkCard6.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard6.Image")));
            this.sharkCard6.Location = new System.Drawing.Point(26, 299);
            this.sharkCard6.Name = "sharkCard6";
            this.sharkCard6.Size = new System.Drawing.Size(100, 50);
            this.sharkCard6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard6.TabIndex = 1;
            this.sharkCard6.TabStop = false;
            // 
            // sharkCard5
            // 
            this.sharkCard5.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard5.Image")));
            this.sharkCard5.Location = new System.Drawing.Point(26, 243);
            this.sharkCard5.Name = "sharkCard5";
            this.sharkCard5.Size = new System.Drawing.Size(100, 50);
            this.sharkCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard5.TabIndex = 1;
            this.sharkCard5.TabStop = false;
            // 
            // sharkCard4
            // 
            this.sharkCard4.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard4.Image")));
            this.sharkCard4.Location = new System.Drawing.Point(26, 187);
            this.sharkCard4.Name = "sharkCard4";
            this.sharkCard4.Size = new System.Drawing.Size(100, 50);
            this.sharkCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard4.TabIndex = 1;
            this.sharkCard4.TabStop = false;
            // 
            // sharkCard3
            // 
            this.sharkCard3.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard3.Image")));
            this.sharkCard3.Location = new System.Drawing.Point(26, 131);
            this.sharkCard3.Name = "sharkCard3";
            this.sharkCard3.Size = new System.Drawing.Size(100, 50);
            this.sharkCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard3.TabIndex = 1;
            this.sharkCard3.TabStop = false;
            // 
            // sharkCard2
            // 
            this.sharkCard2.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard2.Image")));
            this.sharkCard2.Location = new System.Drawing.Point(26, 75);
            this.sharkCard2.Name = "sharkCard2";
            this.sharkCard2.Size = new System.Drawing.Size(100, 50);
            this.sharkCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard2.TabIndex = 1;
            this.sharkCard2.TabStop = false;
            // 
            // sharkCard1
            // 
            this.sharkCard1.Image = ((System.Drawing.Image)(resources.GetObject("sharkCard1.Image")));
            this.sharkCard1.Location = new System.Drawing.Point(26, 19);
            this.sharkCard1.Name = "sharkCard1";
            this.sharkCard1.Size = new System.Drawing.Size(100, 50);
            this.sharkCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sharkCard1.TabIndex = 1;
            this.sharkCard1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.hawkCard1);
            this.groupBox4.Controls.Add(this.hawkCard2);
            this.groupBox4.Controls.Add(this.hawkCard3);
            this.groupBox4.Controls.Add(this.hawkCard4);
            this.groupBox4.Controls.Add(this.hawkCard5);
            this.groupBox4.Controls.Add(this.hawkCard6);
            this.groupBox4.Controls.Add(this.hawkCard7);
            this.groupBox4.Controls.Add(this.hawkCard8);
            this.groupBox4.Controls.Add(this.hawkCard9);
            this.groupBox4.Controls.Add(this.hawkCard10);
            this.groupBox4.Controls.Add(this.hawkCard11);
            this.groupBox4.Controls.Add(this.hawkCard12);
            this.groupBox4.Controls.Add(this.hawkCard13);
            this.groupBox4.Location = new System.Drawing.Point(1263, 15);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(152, 774);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Hawk\'s Hand";
            // 
            // hawkCard1
            // 
            this.hawkCard1.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard1.Image")));
            this.hawkCard1.Location = new System.Drawing.Point(26, 691);
            this.hawkCard1.Name = "hawkCard1";
            this.hawkCard1.Size = new System.Drawing.Size(100, 50);
            this.hawkCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard1.TabIndex = 1;
            this.hawkCard1.TabStop = false;
            // 
            // hawkCard2
            // 
            this.hawkCard2.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard2.Image")));
            this.hawkCard2.Location = new System.Drawing.Point(26, 635);
            this.hawkCard2.Name = "hawkCard2";
            this.hawkCard2.Size = new System.Drawing.Size(100, 50);
            this.hawkCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard2.TabIndex = 1;
            this.hawkCard2.TabStop = false;
            // 
            // hawkCard3
            // 
            this.hawkCard3.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard3.Image")));
            this.hawkCard3.Location = new System.Drawing.Point(26, 579);
            this.hawkCard3.Name = "hawkCard3";
            this.hawkCard3.Size = new System.Drawing.Size(100, 50);
            this.hawkCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard3.TabIndex = 1;
            this.hawkCard3.TabStop = false;
            // 
            // hawkCard4
            // 
            this.hawkCard4.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard4.Image")));
            this.hawkCard4.Location = new System.Drawing.Point(26, 523);
            this.hawkCard4.Name = "hawkCard4";
            this.hawkCard4.Size = new System.Drawing.Size(100, 50);
            this.hawkCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard4.TabIndex = 1;
            this.hawkCard4.TabStop = false;
            // 
            // hawkCard5
            // 
            this.hawkCard5.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard5.Image")));
            this.hawkCard5.Location = new System.Drawing.Point(26, 467);
            this.hawkCard5.Name = "hawkCard5";
            this.hawkCard5.Size = new System.Drawing.Size(100, 50);
            this.hawkCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard5.TabIndex = 1;
            this.hawkCard5.TabStop = false;
            // 
            // hawkCard6
            // 
            this.hawkCard6.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard6.Image")));
            this.hawkCard6.Location = new System.Drawing.Point(26, 411);
            this.hawkCard6.Name = "hawkCard6";
            this.hawkCard6.Size = new System.Drawing.Size(100, 50);
            this.hawkCard6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard6.TabIndex = 1;
            this.hawkCard6.TabStop = false;
            // 
            // hawkCard7
            // 
            this.hawkCard7.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard7.Image")));
            this.hawkCard7.Location = new System.Drawing.Point(26, 355);
            this.hawkCard7.Name = "hawkCard7";
            this.hawkCard7.Size = new System.Drawing.Size(100, 50);
            this.hawkCard7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard7.TabIndex = 1;
            this.hawkCard7.TabStop = false;
            // 
            // hawkCard8
            // 
            this.hawkCard8.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard8.Image")));
            this.hawkCard8.Location = new System.Drawing.Point(26, 299);
            this.hawkCard8.Name = "hawkCard8";
            this.hawkCard8.Size = new System.Drawing.Size(100, 50);
            this.hawkCard8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard8.TabIndex = 1;
            this.hawkCard8.TabStop = false;
            // 
            // hawkCard9
            // 
            this.hawkCard9.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard9.Image")));
            this.hawkCard9.Location = new System.Drawing.Point(26, 243);
            this.hawkCard9.Name = "hawkCard9";
            this.hawkCard9.Size = new System.Drawing.Size(100, 50);
            this.hawkCard9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard9.TabIndex = 1;
            this.hawkCard9.TabStop = false;
            // 
            // hawkCard10
            // 
            this.hawkCard10.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard10.Image")));
            this.hawkCard10.Location = new System.Drawing.Point(26, 187);
            this.hawkCard10.Name = "hawkCard10";
            this.hawkCard10.Size = new System.Drawing.Size(100, 50);
            this.hawkCard10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard10.TabIndex = 1;
            this.hawkCard10.TabStop = false;
            // 
            // hawkCard11
            // 
            this.hawkCard11.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard11.Image")));
            this.hawkCard11.Location = new System.Drawing.Point(26, 131);
            this.hawkCard11.Name = "hawkCard11";
            this.hawkCard11.Size = new System.Drawing.Size(100, 50);
            this.hawkCard11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard11.TabIndex = 1;
            this.hawkCard11.TabStop = false;
            // 
            // hawkCard12
            // 
            this.hawkCard12.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard12.Image")));
            this.hawkCard12.Location = new System.Drawing.Point(26, 75);
            this.hawkCard12.Name = "hawkCard12";
            this.hawkCard12.Size = new System.Drawing.Size(100, 50);
            this.hawkCard12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard12.TabIndex = 1;
            this.hawkCard12.TabStop = false;
            // 
            // hawkCard13
            // 
            this.hawkCard13.Image = ((System.Drawing.Image)(resources.GetObject("hawkCard13.Image")));
            this.hawkCard13.Location = new System.Drawing.Point(26, 19);
            this.hawkCard13.Name = "hawkCard13";
            this.hawkCard13.Size = new System.Drawing.Size(100, 50);
            this.hawkCard13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hawkCard13.TabIndex = 1;
            this.hawkCard13.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tigerCard13);
            this.groupBox2.Controls.Add(this.tigerCard12);
            this.groupBox2.Controls.Add(this.tigerCard11);
            this.groupBox2.Controls.Add(this.tigerCard10);
            this.groupBox2.Controls.Add(this.tigerCard9);
            this.groupBox2.Controls.Add(this.tigerCard8);
            this.groupBox2.Controls.Add(this.tigerCard7);
            this.groupBox2.Controls.Add(this.tigerCard6);
            this.groupBox2.Controls.Add(this.tigerCard5);
            this.groupBox2.Controls.Add(this.tigerCard4);
            this.groupBox2.Controls.Add(this.tigerCard3);
            this.groupBox2.Controls.Add(this.tigerCard2);
            this.groupBox2.Controls.Add(this.tigerCard1);
            this.groupBox2.Location = new System.Drawing.Point(170, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1081, 131);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tiger\'s Hand";
            // 
            // tigerCard13
            // 
            this.tigerCard13.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard13.Image")));
            this.tigerCard13.Location = new System.Drawing.Point(978, 19);
            this.tigerCard13.Name = "tigerCard13";
            this.tigerCard13.Size = new System.Drawing.Size(75, 100);
            this.tigerCard13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard13.TabIndex = 1;
            this.tigerCard13.TabStop = false;
            // 
            // tigerCard12
            // 
            this.tigerCard12.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard12.Image")));
            this.tigerCard12.Location = new System.Drawing.Point(897, 19);
            this.tigerCard12.Name = "tigerCard12";
            this.tigerCard12.Size = new System.Drawing.Size(75, 100);
            this.tigerCard12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard12.TabIndex = 1;
            this.tigerCard12.TabStop = false;
            // 
            // tigerCard11
            // 
            this.tigerCard11.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard11.Image")));
            this.tigerCard11.Location = new System.Drawing.Point(816, 19);
            this.tigerCard11.Name = "tigerCard11";
            this.tigerCard11.Size = new System.Drawing.Size(75, 100);
            this.tigerCard11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard11.TabIndex = 1;
            this.tigerCard11.TabStop = false;
            // 
            // tigerCard10
            // 
            this.tigerCard10.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard10.Image")));
            this.tigerCard10.Location = new System.Drawing.Point(735, 19);
            this.tigerCard10.Name = "tigerCard10";
            this.tigerCard10.Size = new System.Drawing.Size(75, 100);
            this.tigerCard10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard10.TabIndex = 1;
            this.tigerCard10.TabStop = false;
            // 
            // tigerCard9
            // 
            this.tigerCard9.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard9.Image")));
            this.tigerCard9.Location = new System.Drawing.Point(654, 19);
            this.tigerCard9.Name = "tigerCard9";
            this.tigerCard9.Size = new System.Drawing.Size(75, 100);
            this.tigerCard9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard9.TabIndex = 1;
            this.tigerCard9.TabStop = false;
            // 
            // tigerCard8
            // 
            this.tigerCard8.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard8.Image")));
            this.tigerCard8.Location = new System.Drawing.Point(573, 19);
            this.tigerCard8.Name = "tigerCard8";
            this.tigerCard8.Size = new System.Drawing.Size(75, 100);
            this.tigerCard8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard8.TabIndex = 1;
            this.tigerCard8.TabStop = false;
            // 
            // tigerCard7
            // 
            this.tigerCard7.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard7.Image")));
            this.tigerCard7.Location = new System.Drawing.Point(492, 19);
            this.tigerCard7.Name = "tigerCard7";
            this.tigerCard7.Size = new System.Drawing.Size(75, 100);
            this.tigerCard7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard7.TabIndex = 1;
            this.tigerCard7.TabStop = false;
            // 
            // tigerCard6
            // 
            this.tigerCard6.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard6.Image")));
            this.tigerCard6.Location = new System.Drawing.Point(411, 19);
            this.tigerCard6.Name = "tigerCard6";
            this.tigerCard6.Size = new System.Drawing.Size(75, 100);
            this.tigerCard6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard6.TabIndex = 1;
            this.tigerCard6.TabStop = false;
            // 
            // tigerCard5
            // 
            this.tigerCard5.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard5.Image")));
            this.tigerCard5.Location = new System.Drawing.Point(330, 19);
            this.tigerCard5.Name = "tigerCard5";
            this.tigerCard5.Size = new System.Drawing.Size(75, 100);
            this.tigerCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard5.TabIndex = 1;
            this.tigerCard5.TabStop = false;
            // 
            // tigerCard4
            // 
            this.tigerCard4.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard4.Image")));
            this.tigerCard4.Location = new System.Drawing.Point(249, 19);
            this.tigerCard4.Name = "tigerCard4";
            this.tigerCard4.Size = new System.Drawing.Size(75, 100);
            this.tigerCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard4.TabIndex = 1;
            this.tigerCard4.TabStop = false;
            // 
            // tigerCard3
            // 
            this.tigerCard3.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard3.Image")));
            this.tigerCard3.Location = new System.Drawing.Point(168, 19);
            this.tigerCard3.Name = "tigerCard3";
            this.tigerCard3.Size = new System.Drawing.Size(75, 100);
            this.tigerCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard3.TabIndex = 1;
            this.tigerCard3.TabStop = false;
            // 
            // tigerCard2
            // 
            this.tigerCard2.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard2.Image")));
            this.tigerCard2.Location = new System.Drawing.Point(87, 19);
            this.tigerCard2.Name = "tigerCard2";
            this.tigerCard2.Size = new System.Drawing.Size(75, 100);
            this.tigerCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard2.TabIndex = 1;
            this.tigerCard2.TabStop = false;
            // 
            // tigerCard1
            // 
            this.tigerCard1.Image = ((System.Drawing.Image)(resources.GetObject("tigerCard1.Image")));
            this.tigerCard1.Location = new System.Drawing.Point(6, 19);
            this.tigerCard1.Name = "tigerCard1";
            this.tigerCard1.Size = new System.Drawing.Size(75, 100);
            this.tigerCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tigerCard1.TabIndex = 1;
            this.tigerCard1.TabStop = false;
            // 
            // rulesButton
            // 
            this.rulesButton.Location = new System.Drawing.Point(1176, 591);
            this.rulesButton.Name = "rulesButton";
            this.rulesButton.Size = new System.Drawing.Size(75, 36);
            this.rulesButton.TabIndex = 1;
            this.rulesButton.Text = "Show Rules";
            this.rulesButton.UseVisualStyleBackColor = true;
            this.rulesButton.Click += new System.EventHandler(this.rulesButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(1176, 629);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 2;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // showScoreButton
            // 
            this.showScoreButton.Location = new System.Drawing.Point(1176, 552);
            this.showScoreButton.Name = "showScoreButton";
            this.showScoreButton.Size = new System.Drawing.Size(75, 36);
            this.showScoreButton.TabIndex = 1;
            this.showScoreButton.Text = "Show Total Score";
            this.showScoreButton.UseVisualStyleBackColor = true;
            this.showScoreButton.Click += new System.EventHandler(this.showScoreButton_Click);
            // 
            // dealButton
            // 
            this.dealButton.Location = new System.Drawing.Point(419, 554);
            this.dealButton.Name = "dealButton";
            this.dealButton.Size = new System.Drawing.Size(75, 35);
            this.dealButton.TabIndex = 5;
            this.dealButton.Text = "Click to Deal Cards";
            this.dealButton.UseVisualStyleBackColor = true;
            this.dealButton.Click += new System.EventHandler(this.dealButton_Click);
            // 
            // continueButton
            // 
            this.continueButton.Enabled = false;
            this.continueButton.Location = new System.Drawing.Point(869, 553);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(75, 35);
            this.continueButton.TabIndex = 6;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = true;
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // leadingSuitTextBox
            // 
            this.leadingSuitTextBox.Location = new System.Drawing.Point(966, 190);
            this.leadingSuitTextBox.Name = "leadingSuitTextBox";
            this.leadingSuitTextBox.Size = new System.Drawing.Size(275, 20);
            this.leadingSuitTextBox.TabIndex = 7;
            this.leadingSuitTextBox.Text = "Click the Deal Cards Button";
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(1182, 146);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 36);
            this.newGameButton.TabIndex = 8;
            this.newGameButton.Text = "Start New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // cheatButton
            // 
            this.cheatButton.Location = new System.Drawing.Point(1182, 216);
            this.cheatButton.Name = "cheatButton";
            this.cheatButton.Size = new System.Drawing.Size(75, 43);
            this.cheatButton.TabIndex = 9;
            this.cheatButton.Text = "Submit Cheat";
            this.cheatButton.UseVisualStyleBackColor = true;
            this.cheatButton.Click += new System.EventHandler(this.cheatButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1432, 806);
            this.Controls.Add(this.cheatButton);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.leadingSuitTextBox);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.dealButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.showScoreButton);
            this.Controls.Add(this.rulesButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.playersHand);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Hearts";
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tigerPlayedCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkPlayedCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkPlayedCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPlayedCard)).EndInit();
            this.playersHand.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.playerCard12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard0)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sharkCard1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hawkCard13)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tigerCard1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox tigerPlayedCard;
        private System.Windows.Forms.PictureBox hawkPlayedCard;
        private System.Windows.Forms.PictureBox sharkPlayedCard;
        private System.Windows.Forms.PictureBox playerPlayedCard;
        private System.Windows.Forms.GroupBox playersHand;
        private System.Windows.Forms.PictureBox playerCard12;
        private System.Windows.Forms.PictureBox playerCard11;
        private System.Windows.Forms.PictureBox playerCard10;
        private System.Windows.Forms.PictureBox playerCard9;
        private System.Windows.Forms.PictureBox playerCard8;
        private System.Windows.Forms.PictureBox playerCard7;
        private System.Windows.Forms.PictureBox playerCard6;
        private System.Windows.Forms.PictureBox playerCard5;
        private System.Windows.Forms.PictureBox playerCard4;
        private System.Windows.Forms.PictureBox playerCard3;
        private System.Windows.Forms.PictureBox playerCard2;
        private System.Windows.Forms.PictureBox playerCard1;
        private System.Windows.Forms.PictureBox playerCard0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox sharkCard13;
        private System.Windows.Forms.PictureBox sharkCard12;
        private System.Windows.Forms.PictureBox sharkCard11;
        private System.Windows.Forms.PictureBox sharkCard10;
        private System.Windows.Forms.PictureBox sharkCard9;
        private System.Windows.Forms.PictureBox sharkCard8;
        private System.Windows.Forms.PictureBox sharkCard7;
        private System.Windows.Forms.PictureBox sharkCard6;
        private System.Windows.Forms.PictureBox sharkCard5;
        private System.Windows.Forms.PictureBox sharkCard4;
        private System.Windows.Forms.PictureBox sharkCard3;
        private System.Windows.Forms.PictureBox sharkCard2;
        private System.Windows.Forms.PictureBox sharkCard1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox hawkCard1;
        private System.Windows.Forms.PictureBox hawkCard2;
        private System.Windows.Forms.PictureBox hawkCard3;
        private System.Windows.Forms.PictureBox hawkCard4;
        private System.Windows.Forms.PictureBox hawkCard5;
        private System.Windows.Forms.PictureBox hawkCard6;
        private System.Windows.Forms.PictureBox hawkCard7;
        private System.Windows.Forms.PictureBox hawkCard8;
        private System.Windows.Forms.PictureBox hawkCard9;
        private System.Windows.Forms.PictureBox hawkCard10;
        private System.Windows.Forms.PictureBox hawkCard11;
        private System.Windows.Forms.PictureBox hawkCard12;
        private System.Windows.Forms.PictureBox hawkCard13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox tigerCard13;
        private System.Windows.Forms.PictureBox tigerCard12;
        private System.Windows.Forms.PictureBox tigerCard11;
        private System.Windows.Forms.PictureBox tigerCard10;
        private System.Windows.Forms.PictureBox tigerCard9;
        private System.Windows.Forms.PictureBox tigerCard8;
        private System.Windows.Forms.PictureBox tigerCard7;
        private System.Windows.Forms.PictureBox tigerCard6;
        private System.Windows.Forms.PictureBox tigerCard5;
        private System.Windows.Forms.PictureBox tigerCard4;
        private System.Windows.Forms.PictureBox tigerCard3;
        private System.Windows.Forms.PictureBox tigerCard2;
        private System.Windows.Forms.PictureBox tigerCard1;
        private System.Windows.Forms.Button rulesButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button showScoreButton;
        private System.Windows.Forms.Button dealButton;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.TextBox leadingSuitTextBox;
        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button cheatButton;
    }
}

